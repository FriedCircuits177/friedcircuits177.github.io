include(Resources.id("mtrsteamloco:scripts/display_helper.js"));

importPackage(java.awt)