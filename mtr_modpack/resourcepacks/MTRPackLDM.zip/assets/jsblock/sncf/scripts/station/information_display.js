include(Resources.id("jsblock:scripts/pids_util.js"));

include(Resources.id("jsblock:sncf/scripts/utils/sncf_utils.js"));
include(Resources.id("jsblock:sncf/scripts/utils/trains_types.js"));
include(Resources.id("jsblock:sncf/scripts/utils/warning_manager.js"));

const totalHeight = 68.6;

const MAX_VISIBLE_LINES = 13;
const LINE_HEIGHT = 5;
const TIME_BETWEEN_STATES = 5;

const ScrollState = {
    BEGIN: "BEGIN",
    SCROLLING: "SCROLLING",
    END: "END"
};

/* Optionnel */
const defaultText = [
    "Cet affichage en gare n'est toujours pas disponible.",
    "Attendez une version ultérieure pour l'avoir en état de marche.",
    "",
    ""
]

function create(ctx, state, pids) {
    if(state.scroll != null) return;

    state.scroll = {
        currentState: ScrollState.BEGIN,
        currentLineIndex: 0,
        isTextNull: true,
        lines: [],
        text: [],
        lastScrollTime: null,
        lastStateChangeTime: null,
        scrollOffset: 0,
        scrollInterval: null
    };
}

function render(ctx, state, pids) {
    Texture.create()
    .texture("jsblock:sncf/images/backgrounds/information_background.png")
    .size(pids.width, pids.height)
    .draw(ctx);

    if(pids.arrivals().get(0) != null || pids.arrivals().get(0) == null) {
        let text = state.scroll.text;
        if(text.length != 0) text = [];

        for(let i = 0; i < defaultText.length; i++) {
            if(defaultText[i] != "") text.push(SncfUtils.formatText(defaultText[i]));
        }

        drawTextInformation(ctx, state, pids, text);
        drawHeaderAndFooter(ctx, pids);

        SncfUtils.drawClock(ctx, pids, Date.now());
        SncfUtils.drawFrame(ctx, pids, 9.8, true);
    }
}

function dispose(ctx, state, pids) {}

function drawHeaderAndFooter(ctx, pids) {
    Texture.create()
    .texture("jsblock:sncf/images/backgrounds/information_header.png")
    .size(pids.width, pids.height)
    .draw(ctx);

    Texture.create()
    .texture("jsblock:sncf/images/backgrounds/information_bottom_2.png")
    .size(pids.width, pids.height)
    .draw(ctx);
}

function drawTextInformation(ctx, state, pids, text) {

    let lines = splitTextIntoLines(text);
    let scroll = state.scroll;

    let maxI = text.length > MAX_VISIBLE_LINES ? MAX_VISIBLE_LINES : text.length;
    let startY = 6;

    for (let i = 0; i < maxI; i++) {
        Text.create()
        .text(text[i])
        .color(0x00357A)
        .leftAlign()
        .scale(0.45)
        .size(200, LINE_HEIGHT)
        .pos(59, startY + (i * (LINE_HEIGHT + 0.5)) - scroll.scrollOffset)
        .draw(ctx);
    }

}

function handleScrollState(ctx, scroll, pids) {
    const scrollState = scroll.currentState;
    const now = Date.now();

    if(scroll.lastScrollTime == null) scroll.lastScrollTime = now;
    if(scroll.lastStateChangeTime == null) scroll.lastStateChangeTime = now;

    switch(scrollState) {
        case ScrollState.BEGIN:
            if((now - scroll.lastStateChangeTime) > TIME_BETWEEN_STATES * 1000) {
                scroll.currentState = ScrollState.SCROLLING;
                scroll.lastStateChangeTime = now;
                scroll.scrollInterval = now + 30;
            }
            break;
        case ScrollState.SCROLLING:
            if(scroll.scrollInterval != null && now > scroll.scrollInterval) {
                scroll.scrollInterval = now + 30;

                scroll.scrollOffset += 0.075;

                if (scroll.currentLineIndex >= scroll.lines.length - (MAX_VISIBLE_LINES + 1) && scroll.scrollOffset >= (LINE_HEIGHT + 0.25)) {
                    scroll.currentState = ScrollState.END;
                    scroll.lastStateChangeTime = now;
                    scroll.scrollInterval = null;
                    break;
                }

                if (scroll.scrollOffset >= (LINE_HEIGHT + 0.25) && scrollState === ScrollState.SCROLLING) {
                    scroll.currentLineIndex++;
                    scroll.scrollOffset = -1.5;

                    if (scroll.currentLineIndex > scroll.lines.length - (MAX_VISIBLE_LINES + 1)) {
                        scroll.currentLineIndex = scroll.lines.length - (MAX_VISIBLE_LINES + 1);
                    }
                }
            }
            break;
        case ScrollState.END:
            if((now - scroll.lastStateChangeTime) > TIME_BETWEEN_STATES * 1000) {
                scroll.currentState = ScrollState.BEGIN;
                scroll.lastStateChangeTime = now;
                scroll.scrollOffset = -1.5;
                scroll.currentLineIndex = 0;
            }
            break;
    }
}

function wordWrap(text, maxLength) {
    let words = text.split(" ");
    let lines = [];
    let currentLine = "";
    for (let i = 0; i < words.length; i++) {
        let word = words[i];
        if (currentLine === "") {
            currentLine = word;
        } else {
            if (currentLine.length + 1 + word.length <= maxLength) {
                currentLine += " " + word;
            } else {
                lines.push(currentLine);
                currentLine = word;
            }
        }
    }
    if (currentLine !== "") {
        lines.push(currentLine);
    }
    return lines;
}
  
function splitTextIntoLines(textBlocks) {
    let result = [];
    for (let i = 0; i < textBlocks.length; i++) {
        let block = textBlocks[i];
        let blockLines = block.split("\n");
        for (let j = 0; j < blockLines.length; j++) {
            let line = blockLines[j].trim();
            if (line.length === 0) continue;

            let wrappedLines = wordWrap(line, 30);
            for (let k = 0; k < wrappedLines.length; k++) {
                result.push(wrappedLines[k]);
            }
        }
        if (i < textBlocks.length - 1) {
            result.push(" ");
        }
    }
    return result;
}