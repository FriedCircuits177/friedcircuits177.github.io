const SncfUtils = {
    // DEBUG TEXT DRAWING
    drawText(ctx, text, x, y) {
        Text.create()
        .text(text)
        .scale(0.5)
        .pos(x, y)
        .color(0xDB0004)
        .draw(ctx);
    },

    // DRAW PIDS FRAME
    drawFrame(ctx, pids, size, showLogo) {
        Texture.create("Frame-Top")
            .texture("jsblock:sncf/images/gray.png")
            .size(pids.width + (size * 2), size)
            .pos(-size, -size)
            .draw(ctx);
    
        Texture.create("Frame-Bottom")
            .texture("jsblock:sncf/images/gray.png")
            .size(pids.width + (size * 2), size)
            .pos(-size, pids.height)
            .draw(ctx);
    
        Texture.create("Frame-Left")
            .texture("jsblock:sncf/images/gray.png")
            .size(size, pids.height + (size * 2))
            .pos(-size, -size)
            .draw(ctx);
    
        Texture.create("Frame-Right")
            .texture("jsblock:sncf/images/gray.png")
            .size(size, pids.height + (size * 2))
            .pos(pids.width, -size)
            .draw(ctx);
    
        if(showLogo) Texture.create("Sncf Logo")
            .texture("jsblock:sncf/images/labels/sncf.png")
            .size(6.5, 4)
            .pos(pids.width + (size * 0.2), pids.height + (size * 0.4))
            .draw(ctx);
    },

    // GENERATE RANDOM STATION NAMES
    genStations(num) {
        const elements = {
            prefixes: ["La", "Le", "Les", "Saint", "Sainte", "St", "Ste", "Vieux", "Grand", "Petit"],
            radicaux: ["Douz", "Chat", "Mont", "Val", "Bois", "Ville", "Mer", "Champ", "Rivière", "Pont", "Roche", "Fontaine", "Château", "Plaine"],
            suffixes: ["-Canal", "-Ville", "-Nord", "-Sud", "-Chapelle", "-TGV", "-Port"],
            geos: ["Seine", "Loire", "Rhône", "Marne", "Yonne", "Moselle", "Oise", "Saône", "Cher", "Aube", "Somme", "Vienne", "Allier"]
        };
    
        // Mélange manuel des éléments pour varier les combinaisons
        function shuffle(arr) {
            for (let i = arr.length - 1; i > 0; i--) {
                let j = Math.floor(Math.random() * (i + 1));
                let temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
            return arr;
        }
    
        let shuffledPrefixes = shuffle(elements.prefixes.slice());
        let shuffledRadicaux = shuffle(elements.radicaux.slice());
        let shuffledGeos = shuffle(elements.geos.slice());
        
        let result = [];
        let existingNames = {};
        let idx = 0;
    
        for (let i = 0; i < num; i++) {
            let prefix = shuffledPrefixes[idx % shuffledPrefixes.length];
            let radical = shuffledRadicaux[idx % shuffledRadicaux.length];
            let geo = shuffledGeos[idx % shuffledGeos.length];
            idx++;
    
            // Patterns de base
            let patterns = [
                prefix + "-" + radical,
                radical + "-sur-" + geo,
                "Les-" + radical + "s",
                prefix + "-" + geo
            ];
    
            let baseName = patterns[Math.floor(Math.random() * patterns.length)];
            let finalName = baseName;
            let suffixIndex = 0;
    
            // Gestion des doublons avec suffixes alternatifs
            while (existingNames[finalName]) {
                finalName = baseName.split("-")[0] + elements.suffixes[suffixIndex % elements.suffixes.length];
                suffixIndex++;
            }
    
            existingNames[finalName] = true;
            result.push({
                name: finalName,
                id: "id-" + Math.random().toString().substr(2, 9) + Date.now()
            });
        }
    
        return result;
    },

    // CONVERT STATION NAME TO LINES
    formatStationName(name) {
        maxLength = 13;
    
        const lines = [];
        const viaSplit = name.split(' Via ');
        let mainParts = viaSplit[0].split(/[ -]/);
        const viaParts = viaSplit[1] ? viaSplit[1].split(/[ -]/) : [];
    
        let currentLine = '';
        mainParts.forEach((part, index) => {
            const potential = currentLine ? `${currentLine}-${part}` : part;
    
            if (potential.length <= maxLength) {
                currentLine = potential;
            } else {
                if (currentLine) {
                    lines.push({ text: currentLine, margin: lines.length === 0 ? 0 : 0.5 });
                }
                currentLine = part;
            }
    
            if (index === mainParts.length - 1 && currentLine) {
                lines.push({ text: currentLine, margin: lines.length === 0 ? 0 : 0.5 });
            }
        });
    
        if (viaParts.length > 0) {
            lines.push({ text: `Via ${viaParts[0]}`, margin: 0.5 });
    
            let viaCurrent = '';
            viaParts.slice(1).forEach((part, index) => {
                const potential = viaCurrent ? `${viaCurrent}-${part}` : part;
    
                if (potential.length <= maxLength) {
                    viaCurrent = potential;
                } else {
                    if (viaCurrent) {
                        lines.push({ text: viaCurrent, margin: 0.5 });
                    }
                    viaCurrent = part;
                }
    
                if (index === viaParts.length - 2 && viaCurrent) {
                    lines.push({ text: viaCurrent.replace(/-/g, ' '), margin: 0.5 });
                }
            });
        }
    
        return lines;
    },
    shortenNames(name) {
        const replacements = {
            "Saint": "St",
            "Sainte": "Ste",
            "Fort": "Ft",
            "Château": "Ch",
            "Grand": "Gd",
            "Petit": "Pt",
            "Notre-Dame": "N-Dame",
            "-Ville": "",
        };
    
        const specialCases = {
            "Paris Gare de Lyon": "Paris-Gare-de-Lyon",
            "Paris Montparnasse": "Paris-Montparnasse", 
            "Aéroport Charles de Gaulle": "Aéroport CDG"
        };
    
        for (let i = 0; i < specialCases.length; i++) {
            let specialName = specialCases[i];
    
            if (name === specialName) return specialCases[specialName];
        }
    
        let parts = name.split('-');
        let formattedParts = [];
    
        for (let i = 0; i < parts.length; i++) {
            let part = parts[i];
            let replaced = false;
            
            let keys = Object.keys(replacements);
            for (let j = 0; j < keys.length; j++) {
                let key = keys[j];
                
                if (part === key || part.startsWith(key + '-')) {
                    let newPart = replacements[key] + part.slice(key.length);
                    formattedParts.push(newPart);
                    replaced = true;
                    break;
                }
            }
    
            if (!replaced) {
                if (part.startsWith("l'")) {
                    formattedParts.push("L'" + part.slice(2));
                } else {
                    formattedParts.push(part);
                }
            }
        }
    
        let result = formattedParts.join(' ')
            .replace(/\bde\b/g, 'de')
            .replace(/\bdu\b/g, 'du')
            .replace(/\bdes\b/g, 'des');
    
        return result;
    },
    formatText(sentences) {
        function capitalizeFirst(str) {
            if (str.length === 0) return str;
            return str.charAt(0).toUpperCase() + str.substring(1);
        }
        
        function processWord(word, isFirst) {
            let match = word.match(/^(.+?)([,.?!:;]*)$/);
            if (!match) return word;
            let core = match[1];
            let punct = match[2];
            
            core = core.toLowerCase();
            
            if (isFirst) {
                core = capitalizeFirst(core);
            }
            
            if (/^[a-zA-Z]$/.test(core)) {
                core = core.toUpperCase();
            }
            
            return core + punct;
        }
        
        function fixPunctuationSpacing(sentence) {
            let result = "";
            let punctuationMarks = { "?": true, "!": true, ":": true, ";": true };
            for (let i = 0; i < sentence.length; i++) {
                let ch = sentence.charAt(i);
                if (punctuationMarks[ch]) {
                if (ch === ':' && i + 2 < sentence.length && sentence.charAt(i+1) === '/' && sentence.charAt(i+2) === '/') {
                    result += ch;
                } else {
                    if (result.length > 0 && result.charAt(result.length - 1) !== ' ') {
                    result += " ";
                    }
                    result += ch;
                }
                } else {
                    result += ch;
                }
            }
            return result;
        }
        
        let processedSentences = [];
        for (let j = 0; j < sentences.length; j++) {
            let s = sentences[j];
            s = s.trim();
            if (s === "") continue;
            
            s = s.toLowerCase();
            let words = s.split(/\s+/);
            for (let k = 0; k < words.length; k++) {
                words[k] = processWord(words[k], k === 0);
            }
            s = words.join(" ");
            
            s = fixPunctuationSpacing(s);
            
            if (!/[.!?]$/.test(s)) {
                s += ".";
            }
            
            processedSentences.push(s);
        }
        
        return processedSentences.join(" ");
    },

    // GET WIDTH OF CHARACTER BASED ON PIXEL SIZE
    getCharWidth(char, onePx) {
        
        onePx = onePx || 0.5;
        
        const tiny = "i.,;:!'|"; // 1px
        const extraSmall = "l`•";  // 2px
        const small = "tI\"()*¨{}[] "; // 3px
        const medium = "fk<>°²";  // 4px
        const large = "@~";  // 6px
        const extraLarge = "¤" // 7px
        const defaultWidth = 5; // 5px
    
        if (tiny.indexOf(char) !== -1) return 1 * onePx;
        if (extraSmall.indexOf(char) !== -1) return 2 * onePx;
        if (small.indexOf(char) !== -1) return 3 * onePx;
        if (medium.indexOf(char) !== -1) return 4 * onePx;
        if (large.indexOf(char) !== -1) return 6 * onePx;
        if (extraLarge.indexOf(char) !== -1) return 7 * onePx;
        return defaultWidth * onePx;
    },
    getCharHeight(onePx) {
        return 7 * onePx;
    },
    
    // DRAW CLOCK
    drawClock(ctx, pids, timestamp) {
        Text.create("Clock")
            .text(this.formatTime(timestamp))
            .color(0xFFFFFF)
            .pos(pids.width - 7.25, pids.height - 3.75)
            .scale(0.4)
            .rightAlign()
            .draw(ctx);
    
        Text.create("Clock Fixed Seconds")
            .text(this.getSeconds(timestamp))
            .color(0xFF9F17)
            .pos(pids.width - 3.75, pids.height - 3.1)
            .scale(0.28)
            .rightAlign()
            .draw(ctx);
    },  
    formatTime(timestamp, separator) {
        separator = separator || ":";
    
        const date = new Date(timestamp);
        const hours = date.getHours().toString().padStart(2, "0");
        const minutes = date.getMinutes().toString().padStart(2, "0");
        return `${hours}${separator}${minutes}`;
    },
    getSeconds(timestamp) {
        const date = new Date(timestamp);
        return date.getSeconds().toString().padStart(2, "0");
    }
};