const TRAIN_TYPES = {
    "SNCF": {
        name: "SNCF",
        texture: {
            id: "sncf_white",
            size: [7.5, 4.8] // width, height
        },
        aliases: ["TGV"]
    },
    "TER": {
        name: "TER",
        texture: {
            id: "ter_white",
            size: [7.5, 4]
        },
        aliases: []
    },
    "INOUI": {
        name: "INOUI",
        texture: {
            id: "inoui_white",
            size: [7.5, 4]
        },
        aliases: ["TGVINOUI", "TGVLYRIA", "TGVINOUISNCF", "LYRIA"]
    },
    "OUIGO": {
        name: "OUIGO",
        texture: {
            id: "ouigo_white",
            size: [6.8, 6.8]
        },
        aliases: ["OUIGOSNCF", "TGVOUIGO"]
    },
    "INTERCITIES": {
        name: "INTERCITIES",
        aliases: ["IC", "INTERCITY", "INTERCITÉS", "INTERCITÉ", "INTERCITÉSNCF"]
    },
    "CAR": {
        name: "CAR SNCF",
        aliases: ["AUTOCAR", "BUS", "BUS SNCF"]
    }
};

const ALIAS_MAP = (function () {
    let map = {};
    for (let type in TRAIN_TYPES) {
        if (TRAIN_TYPES.hasOwnProperty(type)) {
            map[TRAIN_TYPES[type].name.toLowerCase()] = type;
            let aliases = TRAIN_TYPES[type].aliases;
            for (let i = 0; i < aliases.length; i++) {
                map[aliases[i].toLowerCase()] = type;
            }
        }
        // à corriger sur les doublons
        map[type.toLowerCase()] = type;
    }
    return map;
})();

const TrainUtils = {
    getType: function (type) {
        return TRAIN_TYPES[type.toUpperCase()] || null;
    },
    getNameOfType: function (type) {
        let trainType = TRAIN_TYPES[type.toUpperCase()];
        return trainType ? trainType.name : null;
    },
    getTextureOfType: function (type) {
        let trainType = TRAIN_TYPES[type.toUpperCase()];
        return trainType ? trainType.texture : TRAIN_TYPES.SNCF.texture;
    },

    findTypeFromAlias: function (alias) {
        return TRAIN_TYPES[ALIAS_MAP[alias.toLowerCase()]] || null;
    },
    findNameFromAlias: function (alias) {
        let type = ALIAS_MAP[alias.toLowerCase()];
        return type ? TRAIN_TYPES[type].name : null;
    },

    isMatchingOneAliasOfType: function(alias, trainType) {
        let aliases = trainType.aliases;
        aliases.push(trainType.name);
        
        for (let i = 0; i < aliases.length; i++) {
            if (aliases[i].toLowerCase() === alias.toLowerCase()) return true;
        }
        return false;
    }
};
