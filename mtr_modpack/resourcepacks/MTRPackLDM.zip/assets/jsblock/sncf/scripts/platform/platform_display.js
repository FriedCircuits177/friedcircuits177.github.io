include(Resources.id("jsblock:scripts/pids_util.js"));

include(Resources.id("jsblock:sncf/scripts/utils/sncf_utils.js"));
include(Resources.id("jsblock:sncf/scripts/utils/train_utils.js"));
include(Resources.id("jsblock:sncf/scripts/utils/warning_manager.js"));

const totalHeight = 68.6;

const MAX_VISIBLE_STOPS = 10;
const STOP_HEIGHT = 5;
const DEPARTURE_MESSAGE_DURATION = 10;
const TIME_BETWEEN_STATES = 3;

const ScrollState = {
    BEGIN: "BEGIN",
    SCROLLING: "SCROLLING",
    END: "END"
};

function create(ctx, state, pids) {
    if(state.scroll != null) return;

    state.scroll = {
        currentState: ScrollState.BEGIN,
        stations: [],
        fixedStations: [],
        isTerminating: false,
        currentStationIndex: 0,
        lastScrollTime: null,
        lastStateChangeTime: null,
        scrollOffset: -1.5,
        scrollInterval: null
    };

    if(state.warningManager == null) state.warningManager = new WarningManager();
}

function render(ctx, state, pids) {
    const departure = pids.arrivals().get(0);

    Texture.create()
    .texture("jsblock:sncf/images/backgrounds/bluescreen.png")
    .size(pids.width, pids.height)
    .draw(ctx);

    if(departure != null && state.scroll != null) {
        const departureTime = departure.departureTime();
        const timestamp = Date.now();
    
        if(departure.terminating()) {
            if (departureTime - timestamp <= 30000 && departureTime - timestamp >= -6000) {
                if (Math.floor(Date.now() / 1000) % 2 == 0) {
                    Texture.create()
                    .texture("jsblock:sncf/images/backgrounds/terminating.png")
                    .size(pids.width, pids.height)
                    .draw(ctx);

                    SncfUtils.drawFrame(ctx, pids, 9.8, true);
                    return;
                }
            }

            Texture.create()
            .texture("jsblock:sncf/images/backgrounds/arrival_background.png")
            .size(pids.width, pids.height)
            .draw(ctx);
        } else {
            if (departureTime - timestamp <= (DEPARTURE_MESSAGE_DURATION * 1000) && departureTime - timestamp >= -6000) {
                Texture.create()
                .texture("jsblock:sncf/images/backgrounds/train_departing.png")
                .size(pids.width, pids.height)
                .draw(ctx);
        
                if (Math.floor(Date.now() / 1000) % 2 == 0) {
                    Texture.create()
                    .texture("jsblock:sncf/images/pictograms/forbidden_boarding.png")
                    .size(55, 55)
                    .pos(21, 7.4)
                    .draw(ctx);
                }

                SncfUtils.drawFrame(ctx, pids, 9.8, true);
                return;
            }

            Texture.create()
            .texture("jsblock:sncf/images/backgrounds/departure_background.png")
            .size(pids.width, pids.height)
            .draw(ctx);
        }

        let platforms = departure.route().platforms; // "NULL"
        let stations = [];

        if(state.scroll.stations.length == 0) {
            for(let i = 0; i < platforms.length; i++) { 
                stations.push({
                    name: platforms[i].stationName,
                    id: platforms[i].platformId
                });
            }

            state.scroll.stations = stations;
            state.scroll.fixedStations = stations;
        }

        if(!departure.terminating()) {
            const currentStation = departure.platformId();
            let currentIndex = state.scroll.stations.findIndex(station => station.id === currentStation);

            if (currentIndex !== -1) {
                state.scroll.stations = state.scroll.stations.slice(currentIndex + 1);
            }
        } else if(state.scroll.isTerminating == false) {
            state.scroll.stations = state.scroll.stations.slice(0, -1);
            state.scroll.isTerminating = true;
        }

        if(state.scroll.stations.length > MAX_VISIBLE_STOPS) handleScrollState(ctx, state.scroll, pids);
        if(state.scroll.stations.length > 0) drawStationList(ctx, state.scroll, pids, departure.terminating());

        drawLeftPanel(ctx, state.scroll, pids, departure);
        drawTextInformation(ctx, state, pids);

        SncfUtils.drawClock(ctx, pids, Date.now());
    } else {
        state.warningManager.update(ctx, pids);
    }

    SncfUtils.drawFrame(ctx, pids, 9.8, false);
}

function dispose(ctx, state, pids) {}

function drawLeftPanel(ctx, scroll, pids, departure) {
    drawTrainDepartureHour(ctx, scroll, pids, departure);
    drawTrainDestination(ctx, scroll, pids, departure);
}

function drawTrainDepartureHour(ctx, scroll, pids, departure) {

    const isTerminating = departure.terminating();
    const color = isTerminating ? 0x006E30 : 0x014494;

    Text.create()
    .text(SncfUtils.formatTime(isTerminating ? departure.arrivalTime() : departure.departureTime(), "h"))
    .color(color)
    .bold()
    .scale(0.6)
    .pos(2.25, 9.425)
    .draw(ctx);

    const onTimeMessages = ["准时", "On time", "時間通りに"];
    Text.create()
    .text(onTimeMessages[Math.floor(Date.now() / 3000) % onTimeMessages.length].toLowerCase())
    .color(color)
    .centerAlign()
    .scale(0.28)
    .pos(34.125, 11.875)
    .draw(ctx);
}

function drawTrainDestination(ctx, scroll, pids, departure) {
    const isTerminating = departure.terminating();
    const color = isTerminating ? 0x006E30 : 0x014494;
    const destination = departure.destination().slice(0);

    let lines = isTerminating ? SncfUtils.formatStationName(scroll.fixedStations[0].name) : SncfUtils.formatStationName(destination);
    let startY = 20;
    const LINE_HEIGHT = 4.5;

    for(let i = 0; i < lines.length; i++) {
        Text.create()
        .text(SncfUtils.shortenNames(lines[i].text))
        .color(color)
        .scale(0.51)
        .size(42.5, LINE_HEIGHT)
        .bold()
        .pos(2.25, startY + (i * (LINE_HEIGHT + lines[i].margin)))
        .draw(ctx);
    }

    let newY = startY + (lines.length * (LINE_HEIGHT + lines[lines.length-1].margin)) + 2.25;

    drawTrainInformation(ctx, scroll, pids, departure, newY);
}

function drawTrainInformation(ctx, scroll, pids, departure, startY) {
    const routeNumber = departure.routeNumber().slice(0).split("|");
    const trainType = routeNumber[0].trim().toLowerCase();
    const trainNumber = routeNumber[1];

    let trainName = TrainUtils.findNameFromAlias(trainType) || "SNCF";

    if (TrainUtils.isMatchingOneAliasOfType(trainName, TRAIN_TYPES.CAR)) {
        Texture.create()
        .texture("jsblock:sncf/images/pictograms/bus-black.png")
        .size(10, 10)
        .pos(1.5, pids.height - 19.5)
        .draw(ctx);
    }

    const trainNamePixelSize = 0.37;
    const startX = 1.9;

    Text.create()
    .text(trainName)
    .color(0x00409D)
    .scale(trainNamePixelSize)
    .leftAlign()
    .pos(startX, startY)
    .draw(ctx);

    scroll.trainNameWidth = 0;

    for(let i = 0; i < trainName.length; i++) {
        scroll.trainNameWidth += SncfUtils.getCharWidth(trainName[i], trainNamePixelSize);
        if(i < trainName.length - 1) scroll.trainNameWidth += trainNamePixelSize;
    }

    const posX = startX + scroll.trainNameWidth + 1.375;
    Text.create()
    .text(trainNumber)
    .color(0x7C86B5)
    .scale(0.35)
    .leftAlign()
    .pos(posX, startY + 0.25)
    .draw(ctx);
}

function drawTextInformation(ctx, state, pids) {
    let text = [];

    for(let i = 0; i < pids.rows; i++) {
        if(pids.getCustomMessage(i) != "") text.push(pids.getCustomMessage(i));
    }

    const TEXT_HEIGHT = 6.25;

    Text.create()
    .text(SncfUtils.formatText(text))
    .color(0xFFFFFF)
    .italic()
    .scale(0.5)
    .marquee()
    .size(224, TEXT_HEIGHT)
    .pos(0.75, pids.height - TEXT_HEIGHT + 0.5)
    .draw(ctx);
}

function handleScrollState(ctx, scroll, pids) {
    const scrollState = scroll.currentState;
    const now = Date.now();

    if(scroll.lastScrollTime == null) scroll.lastScrollTime = now;
    if(scroll.lastStateChangeTime == null) scroll.lastStateChangeTime = now;

    switch(scrollState) {
        case ScrollState.BEGIN:
            if((now - scroll.lastStateChangeTime) > TIME_BETWEEN_STATES * 1000) {
                scroll.currentState = ScrollState.SCROLLING;
                scroll.lastStateChangeTime = now;
                scroll.scrollInterval = now + 30;
            }
            break;
        case ScrollState.SCROLLING:
            if(scroll.scrollInterval != null && now > scroll.scrollInterval) {
                scroll.scrollInterval = now + 30;

                scroll.scrollOffset += 0.075;

                if (scroll.currentStationIndex >= scroll.stations.length - (MAX_VISIBLE_STOPS + 1) && scroll.scrollOffset >= (STOP_HEIGHT + 0.67) * 2) {
                    scroll.currentState = ScrollState.END;
                    scroll.lastStateChangeTime = now;
                    scroll.scrollInterval = null;
                    break;
                }

                if (scroll.scrollOffset >= (STOP_HEIGHT + 0.25) && scrollState === ScrollState.SCROLLING) {
                    scroll.currentStationIndex++;
                    scroll.scrollOffset = -1.5;

                    if (scroll.currentStationIndex > scroll.stations.length - (MAX_VISIBLE_STOPS + 1)) {
                        scroll.currentStationIndex = scroll.stations.length - (MAX_VISIBLE_STOPS + 1);
                    }
                }
            }
            break;
        case ScrollState.END:
            if((now - scroll.lastStateChangeTime) > TIME_BETWEEN_STATES * 1000) {
                scroll.currentState = ScrollState.BEGIN;
                scroll.lastStateChangeTime = now;
                scroll.scrollOffset = -1.5;
                scroll.currentStationIndex = 0;
            }
            break;
    }
}

function drawStationList(ctx, scroll, pids, isTerminating) {
    let stations = scroll.stations;

    const lastStationWidth = stations[stations.length - 1].name.slice(0).length * 2.25;

    const calculateDynamicMargin = (numStations) => {
        const minStations = 2;
        const maxStations = 10;
        const maxMargin = 18;
        const minMargin = 2;
    
        if (numStations <= minStations) {
            return maxMargin;
        } else if (numStations >= maxStations) {
            return minMargin;
        } else {
            const range = maxStations - minStations;
            const progress = (numStations - minStations) / range; 
            const exponent = 2;
            const margin = maxMargin * Math.pow(1 - progress, exponent);
            return Math.max(minMargin, margin);
        }
    };
    
    let dynamicMargin = calculateDynamicMargin(stations.length);

    const totalStopsHeight = stations.length * STOP_HEIGHT;
    const totalMarginHeight = (stations.length - 1) * dynamicMargin;
    const totalContentHeight = totalStopsHeight + totalMarginHeight;

    let startY = -scroll.scrollOffset;
    let maxI = MAX_VISIBLE_STOPS + 1;
    let lineHeightSize = (totalHeight + STOP_HEIGHT) - scroll.scrollOffset;

    if(stations.length < MAX_VISIBLE_STOPS) {
        maxI = stations.length;
        startY = (totalHeight - totalContentHeight) / 2;
        lineHeightSize = startY + (STOP_HEIGHT * stations.length) + (dynamicMargin * (stations.length-1));
    }

    Texture.create()
    .texture(isTerminating ? "jsblock:sncf/images/green_square.png" : "jsblock:sncf/images/aqua_square.png")
    .size(2, lineHeightSize)
    .pos(50.125, 0)
    .draw(ctx);

    for (let i = scroll.scrollOffset > (STOP_HEIGHT + 0.25) ? 1 : 0; i < maxI; i++) {
        const pixelSize = 0.45;
        let stationName = stations[i + scroll.currentStationIndex].name.slice(0);
        stationName = SncfUtils.shortenNames(stationName);

        if(stations[i + scroll.currentStationIndex].id === scroll.fixedStations[scroll.fixedStations.length - 1].id) {
            scroll.lastStationNameWidth = 0;

            for(let j = 0; j < stationName.length; j++) {

                scroll.lastStationNameWidth += SncfUtils.getCharWidth(stationName[j], pixelSize);
                if(j < stationName.length - 1) scroll.lastStationNameWidth += pixelSize;
            }

            Texture.create()
            .texture("jsblock:sncf/images/aqua_square.png")
            .size(4.875 + scroll.lastStationNameWidth + 2.875, STOP_HEIGHT + 2)
            .pos(50.125, startY + (i * (STOP_HEIGHT + dynamicMargin)) - (STOP_HEIGHT / 3))
            .draw(ctx);
        }

        Texture.create()
        .texture("jsblock:sncf/images/pictograms/station_dot.png")
        .size(1.75, 1.75)
        .pos(50.25, startY + (i * (STOP_HEIGHT + dynamicMargin)) + 0.75)
        .draw(ctx);

        Text.create()
        .text(stationName)
        .color(0xFFFFFF)
        .leftAlign()
        .scale(pixelSize)
        .size(75, STOP_HEIGHT)
        .pos(55, startY + (i * (STOP_HEIGHT + dynamicMargin)))
        .draw(ctx);
    }

    if(isTerminating)
        Texture.create()
        .texture("jsblock:sncf/images/backgrounds/arrival_information_background.png")
        .size(pids.width, pids.height)
        .draw(ctx);
    else
        Texture.create()
        .texture("jsblock:sncf/images/backgrounds/departure_information_background.png")
        .size(pids.width, pids.height)
        .draw(ctx);
}