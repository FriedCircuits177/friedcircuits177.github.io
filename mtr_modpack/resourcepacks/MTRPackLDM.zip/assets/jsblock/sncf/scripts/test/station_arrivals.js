include(Resources.id("jsblock:scripts/pids_util.js"));

let ROW_HEIGHT = 16;

let TRAIN_ICONS = {
    "SNCF": {
        "name": "SNCF",
        "texture": "jsblock:images/pids/icons/sncf_white.png",
        "width": 9,
        "height": 6,
        "posX": 1.5,
        "posY": 4.4
    },
    "TER": {
        "name": "TER",
        "texture": "jsblock:images/pids/icons/sncf_white.png",
        "width": 9,
        "height": 6,
        "posX": 1.5,
        "posY": 4.4
    },
    "INOUI": {
        "name": "INOUI",
        "texture": "jsblock:images/pids/icons/inoui_white.png",
        "width": 9.25,
        "height": 4.5,
        "posX": 1.5,
        "posY": 5.75
    },
    "INTERCITIES": {
        "name": "INTERCITIES",
        "texture": "jsblock:images/pids/icons/sncf_white.png",
        "width": 9,
        "height": 6,
        "posX": 1.5,
        "posY": 4.4
    }
}

function create(ctx, state, pids) {}

function render(ctx, state, pids) {
    Texture.create("Background")
    .texture("jsblock:images/pids/sncf_bg-a_test.png")
    .size(pids.width, pids.height)
    .draw(ctx);

    Texture.create("Fake Fifth Row")
    .texture("jsblock:images/pids/sncf_bg-a_odd.png")
    .size(pids.width, 3)
    .pos(0, 4 * ROW_HEIGHT)
    .draw(ctx);

    test = pids.arrivals().get(0);

    for (let i = 0; i < pids.rows; i++) {
        let rowY = i * ROW_HEIGHT;

        let arrival = pids.arrivals().get(i);
        let customMessage = pids.getCustomMessage(i);

        if (arrival != null && !pids.isRowHidden(i)) {
            if(evenNumber(i)) {
                Texture.create("Even Rows Background")
                .texture("jsblock:images/pids/sncf_bg-a_odd.png")
                .size(pids.width, ROW_HEIGHT)
                .pos(0, rowY)
                .draw(ctx);
            }

            let routeNumber = arrival.routeNumber().slice(0).toLowerCase().trim().split("|");
            let trainType = routeNumber[0];
            let trainNumber = routeNumber[1];

            let trainIcon = TRAIN_ICONS["SNCF"];

            switch (trainType) {
                case "ter":
                    trainIcon = TRAIN_ICONS["TER"];
                    break;
                case "inoui":
                case "tgv":
                    trainIcon = TRAIN_ICONS["INOUI"];
                    break;
                case "intercities":
                case "intercités":
                case "intercites":
                case "intercité":
                case "intercite":
                case "intercity":
                case "interc":
                    trainIcon = TRAIN_ICONS["INTERCITIES"];
                    break;
                default:
                    trainIcon = TRAIN_ICONS["SNCF"];
                    break;
            }

            Texture.create("Train Type Icon")
            .texture(trainIcon.texture)
            .pos(trainIcon.posX, rowY + trainIcon.posY)
            .size(trainIcon.width, trainIcon.height)
            .draw(ctx);

            if(customMessage != "") {
                Text.create("Train is Late")
                .text(TextUtil.cycleString(customMessage))
                .color(0xFFFFFF)
                .scale(0.65)
                .pos(20, rowY)
                .draw(ctx);
            }

            Text.create("Departure Time")
            .text(formatTime(arrival.arrivalTime(), "h"))
            .color(0xFEF103)
            .bold()
            .scale(0.55)
            .pos(30.5, rowY + 5.75)
            .draw(ctx);

            Text.create("Destination Name")
            .text(arrival.route().platforms[0].stationName)
            .color(0xFFFFFF)
            .scale(0.65)
            .size(100, 9)
            .marquee()
            .pos(51.5, rowY + 5.25)
            .draw(ctx);

            if (trainType != "bus") {
                Text.create("Train Type")
                .text(trainIcon.name)
                .color(0xFFFFFF)
                .scale(0.28)
                .pos(12.5, rowY + 5.25)
                .draw(ctx);

                Text.create("Train Number")
                .text(trainNumber)
                .color(0xFFFFFF)
                .scale(0.4)
                .bold()
                .pos(12.5, rowY + 7.75)
                .draw(ctx);

                Text.create("Platform Text")
                .centerAlign()
                .text(arrival.platformName())
                .color(0xFFFFFF)
                .scale(0.75)
                .size(7.5, 7.5)
                .scaleXY()
                .pos(pids.width - 7.75, rowY + 5.5)
                .draw(ctx);

                Texture.create("Platform Border")
                .texture("jsblock:images/pids/platform_border.png")
                .pos(pids.width - 13, rowY + 3)
                .size(10, 10)
                .draw(ctx);
            } else {
                Texture.create("Bus Icon")
                .texture("jsblock:images/pids/icons/bus_white.png")
                .pos(pids.width - 13, rowY + 3)
                .size(10, 10)
                .draw(ctx);
            }
        }
    }

    Texture.create("ArrivalsText")
    .texture("jsblock:images/pids/arrivals_90.png")
    .size(14, 62)
    .pos(pids.width - 22.5, 4.5)
    .draw(ctx);

    let timestamp = Date.now();

    Text.create("Clock")
    .text(formatTime(timestamp)) //PIDSUtil.formatTime(MinecraftClient.worldDayTime(), true)
    .color(0xFFFFFF)
    .pos(pids.width - 11.25, pids.height - 4.5)
    .scale(0.4)
    .rightAlign()
    .draw(ctx);

    Text.create("Clock Fixed Seconds")
    .text(getSeconds(Date.now()))
    .color(0xFF9F17)
    .pos(pids.width - 6.5, pids.height - 3.75)
    .scale(0.3)
    .rightAlign()
    .draw(ctx);

    Text.create("Clock Fixed Seconds")
    .text(getSeconds(timestamp))
    .color(0xFF9F17)
    .pos(pids.width - 6.5, pids.height - 3.75)
    .scale(0.3)
    .rightAlign()
    .draw(ctx);

    // FRAME
    
    Texture.create("Frame-Top")
    .texture("jsblock:images/pids/gray.png")
    .size(pids.width + (12*2), 12)
    .pos(-12, -12)
    .draw(ctx);

    Texture.create("Frame-Bottom")
    .texture("jsblock:images/pids/gray.png")
    .size(pids.width + (12*2), 12)
    .pos(-12, pids.height)
    .draw(ctx);

    Texture.create("Frame-Left")
    .texture("jsblock:images/pids/gray.png")
    .size(12, pids.height + (12*2))
    .pos(-12, -12)
    .draw(ctx);

    Texture.create("Frame-Right")
    .texture("jsblock:images/pids/gray.png")
    .size(12, pids.height + (12*2))
    .pos(pids.width, -12)
    .draw(ctx);

    Texture.create("Sncf Logo")
    .texture("jsblock:images/pids/icons/sncf.png")
    .size(6.5, 4)
    .pos(pids.width + 3, pids.height + 5)
    .draw(ctx);

}

function dispose(ctx, state, pids) {}

const evenNumber = (n) => (n%2 == 0);

const checkIfTrainIsLate = (arrival) => {
    let difference =  arrival.arrivalTime() - arrival.departureTime();
    return difference;
}

function formatTime(timestamp, separator) {
    let date = new Date(timestamp);
    let hours = date.getHours().toString().padStart(2, "0");
    let minutes = date.getMinutes().toString().padStart(2, "0");
    return `${hours}${separator || ":"}${minutes}`;
}

function getSeconds(timestamp) {
    let date = new Date(timestamp);
    let seconds = date.getSeconds().toString().padStart(2, "0");
    return seconds;
}