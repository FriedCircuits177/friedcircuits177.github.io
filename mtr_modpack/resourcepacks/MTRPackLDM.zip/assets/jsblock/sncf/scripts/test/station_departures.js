include(Resources.id("jsblock:scripts/pids_util.js"));
include(Resources.id("jsblock:utils/sncf_utils.js"));

let ROW_HEIGHT = 16;

let TRAIN_ICONS = {
    "SNCF": {
        "name": "SNCF",
        "texture": "jsblock:images/pids/icons/sncf_white.png",
        "width": 9,
        "height": 6,
        "posX": 1.5,
        "posY": 4.4
    },
    "TER": {
        "name": "TER",
        "texture": "jsblock:images/pids/icons/sncf_white.png",
        "width": 9,
        "height": 6,
        "posX": 1.5,
        "posY": 4.4
    },
    "INOUI": {
        "name": "TGV INOUI",
        "texture": "jsblock:images/pids/icons/inoui_white.png",
        "width": 9.25,
        "height": 4.5,
        "posX": 1.5,
        "posY": 5.75
    },
    "INTERCITIES": {
        "name": "INTERCITES",
        "texture": "jsblock:images/pids/icons/sncf_white.png",
        "width": 9,
        "height": 6,
        "posX": 1.5,
        "posY": 4.4
    }
}

function create(ctx, state, pids) {}

function render(ctx, state, pids) {
    Texture.create("Background")
    .texture("jsblock:images/pids/sncf_bg_test.png")
    .size(pids.width, pids.height)
    .draw(ctx);

    Texture.create("Fake Fifth Row")
    .texture("jsblock:images/pids/sncf_bg_odd.png")
    .size(pids.width, 3)
    .pos(0, 4 * ROW_HEIGHT)
    .draw(ctx);

    test = pids.arrivals().get(0);

    for (let i = 0; i < pids.rows; i++) {
        let rowY = i * ROW_HEIGHT;

        let arrival = pids.arrivals().get(i);
        let customMessage = pids.getCustomMessage(i);

        if (arrival != null && !pids.isRowHidden(i)) {
            if(evenNumber(i)) {
                Texture.create("Even Rows Background")
                .texture("jsblock:images/pids/sncf_bg_odd.png")
                .size(pids.width, ROW_HEIGHT)
                .pos(0, rowY)
                .draw(ctx);
            }

            let routeNumber = arrival.routeNumber().slice(0).toLowerCase().trim().split("|");
            let trainType = routeNumber[0];
            let trainNumber = routeNumber[1] || " ";

            let trainIcon = TRAIN_ICONS["SNCF"];

            switch (trainType) {
                case "ter":
                    trainIcon = TRAIN_ICONS["TER"];
                    break;
                case "inoui":
                case "tgv":
                    trainIcon = TRAIN_ICONS["INOUI"];
                    break;
                case "intercities":
                case "intercités":
                case "intercites":
                case "intercité":
                case "intercite":
                case "intercity":
                case "interc":
                    trainIcon = TRAIN_ICONS["INTERCITIES"];
                    break;
                default:
                    trainIcon = TRAIN_ICONS["SNCF"];
                    break;
            }

            Texture.create("Train Type Icon")
            .texture(trainIcon.texture)
            .pos(trainIcon.posX, rowY + trainIcon.posY)
            .size(trainIcon.width, trainIcon.height)
            .draw(ctx);

            if(customMessage != "") {
                Text.create("Train is Late")
                .text(TextUtil.cycleString(customMessage))
                .color(0xFFFFFF)
                .scale(0.65)
                .pos(20, rowY)
                .draw(ctx);
            }

            Text.create("Departure Time")
            .text(formatTime(arrival.departureTime(), "h"))
            .color(0xFEF103)
            .bold()
            .scale(0.55)
            .pos(30.5, rowY + 5.75)
            .draw(ctx);

            Text.create("Destination Name")
            .text(arrival.destination())
            .color(0xFFFFFF)
            .scale(0.65)
            .size(100, 9)
            .marquee()
            .pos(51.5, rowY + 5.25)
            .draw(ctx);

            if (trainType != "bus") {
                const onTimeMessages = ["À l'heure", "On time", "In orario"];
                const lateMessages = ["retardé", "late", "in ritardo"];

                let currentTime = Math.floor(Date.now() / 3000);
                let isOnTimeMessage = currentTime % 2 === 0;

                if(isOnTimeMessage) {
                    if(arrival.departureTime() < arrival.arrivalTime()) {
                        Text.create("Train Type")
                        .text(lateMessages[currentTime % lateMessages.length])
                        .color(0xFCD12A)
                        .scale(0.3)
                        .bold()
                        .pos(12.5, rowY + 5.25)
                        .draw(ctx);

                        Text.create("Train Number")
                        .text(getLateTime(arrival))
                        .color(0xFCD12A)
                        .scale(0.3)
                        .bold()
                        .pos(12.5, rowY + 7.75)
                        .draw(ctx);
                    } else {
                        Text.create("Train is On Time")
                        .text(onTimeMessages[currentTime % onTimeMessages.length])
                        .color(0xFFFFFF)
                        .scale(0.5)
                        .centerAlign()
                        .scaleXY()
                        .size(25, 10)
                        .pos(20.75, rowY+5.75)
                        .draw(ctx);
                    }
                } else {
                    Text.create("Train Type")
                    .text(trainIcon.name)
                    .color(0xFFFFFF)
                    .scale(0.28)
                    .pos(12.5, rowY + 5.25)
                    .draw(ctx);

                    Text.create("Train Number")
                    .text(trainNumber)
                    .color(0xFFFFFF)
                    .scale(0.4)
                    .bold()
                    .pos(12.5, rowY + 7.75)
                    .draw(ctx);
                } // onTimeMessages[currentTime % onTimeMessages.length] : `${trainType} ${trainNumber}`;

                /*Text.create("Train Type")
                .text(trainIcon.name)
                .color(0xFFFFFF)
                .scale(0.28)
                .pos(12.5, rowY + 5.25)
                .draw(ctx);

                Text.create("Train Number")
                .text(trainNumber)
                .color(0xFFFFFF)
                .scale(0.4)
                .bold()
                .pos(12.5, rowY + 7.75)
                .draw(ctx);*/

                Text.create("Platform Text")
                .centerAlign()
                .text(arrival.platformName())
                .color(0xFFFFFF)
                .scale(0.75)
                .size(7.5, 7.5)
                .scaleXY()
                .pos(pids.width - 7.75, rowY + 5.5)
                .draw(ctx);

                Texture.create("Platform Border")
                .texture("jsblock:images/pids/platform_border.png")
                .pos(pids.width - 13, rowY + 3)
                .size(10, 10)
                .draw(ctx);
            } else {
                Texture.create("Bus Icon")
                .texture("jsblock:images/pids/icons/bus_white.png")
                .pos(pids.width - 13, rowY + 3)
                .size(10, 10)
                .draw(ctx);
            }
        }
    }

    Texture.create("Departures Image")
    .texture("jsblock:images/pids/departs_90.png")
    .size(16, 60)
    .pos(pids.width - 20.5, 6.5)
    .draw(ctx);

    let timestamp = Date.now();

    Text.create("Clock")
    .text(formatTime(timestamp)) // PIDSUtil.formatTime(MinecraftClient.worldDayTime(), true)
    .color(0xFFFFFF)
    .pos(pids.width - 11.25, pids.height - 4.5)
    .scale(0.4)
    .rightAlign()
    .draw(ctx);

    Text.create("Clock Fixed Seconds")
    .text(getSeconds(timestamp))
    .color(0xFF9F17)
    .pos(pids.width - 6.5, pids.height - 3.75)
    .scale(0.3)
    .rightAlign()
    .draw(ctx);

    // FRAME
    
    SncfUtils.drawFrame(ctx, pids, 9.8, true);

}

function dispose(ctx, state, pids) {}

const evenNumber = (n) => (n%2 == 0);

const getLateTime = (arrival) => {
    let difference =  arrival.arrivalTime() - arrival.departureTime();
    let minutes = difference / 60;
    return `${minutes.toString().padStart(2, "0")}min.`;
}

function formatTime(timestamp, separator) {
    let date = new Date(timestamp);
    let hours = date.getHours().toString().padStart(2, "0");
    let minutes = date.getMinutes().toString().padStart(2, "0");
    return `${hours}${separator || ":"}${minutes}`;
}

function getSeconds(timestamp) {
    let date = new Date(timestamp);
    let seconds = date.getSeconds().toString().padStart(2, "0");
    return seconds;
}

function getAlternatingText(arrival) {
    const trainType = arrival.routeNumber().split("|")[0].toUpperCase();
    const trainNumber = arrival.routeNumber().split("|")[1];

    const onTimeMessages = ["À l'heure", "On time", "In orario", "Pünktlich", "A tiempo"];

    // Change toutes les 3 secondes
    let currentTime = Math.floor(Date.now() / 3000);
    let isOnTimeMessage = currentTime % 2 === 0;

    return isOnTimeMessage ? onTimeMessages[currentTime % onTimeMessages.length] : `${trainType} ${trainNumber}`;
}
