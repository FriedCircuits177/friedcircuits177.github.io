include(Resources.id("jsblock:scripts/pids_util.js"));

include(Resources.id("jsblock:utils/fake_timers.js"));
include(Resources.id("jsblock:sncf/trains_types.js"));
include(Resources.id("jsblock:sncf/warning_manager.js"));

const MAX_VISIBLE_STOPS = 13;
const STOP_HEIGHT = 5;
const DEPARTURE_MESSAGE_DURATION = 10; // in seconds
const timeBetweenStates = 3; // Temps entre chaque état

let lastScroll = null;
let scrollOffset = 0;
let CURRENT_STOP = 0;
let scrollTimeout = null;
let scrollInterval = null;

const ScrollState = {
    BEGIN: "BEGIN",
    SCROLLING: "SCROLLING",
    END: "END"
};

let currentScrollState = ScrollState.BEGIN;
let lastStateChangeTime = Date.now();

const warningManager = new WarningManager({});

function create(ctx, state, pids) {}

function render(ctx, state, pids) {
    FakeTimers.run();

    const departure = pids.arrivals().get(0);
    if (departure == null || pids.isRowHidden(0)) {
        // if(state.warningManager == null) state.warningManager = new WarningManager({});

        warningManager.update(ctx, pids);
        drawFrame(ctx, pids, 10);
        return;
    }

    const departureTime = departure.departureTime();
    const timestamp = Date.now();

    if (departureTime - timestamp <= (DEPARTURE_MESSAGE_DURATION * 1000) && departureTime - timestamp >= -6000) {
        Texture.create("Background")
            .texture("jsblock:images/pids/train_departing_bg.png")
            .size(pids.width, pids.height)
            .draw(ctx);

        if (Math.floor(Date.now() / 1000) % 2 == 0) {
            Texture.create("Departure image")
                .texture("jsblock:images/pids/departure_blinking.png")
                .size(55, 55)
                .pos(21, 7.4)
                .draw(ctx);
        }
    } else {
        drawBackground(ctx, pids);
        drawClock(ctx, pids, timestamp);
        drawDepartureInfo(ctx, departure, pids);
        drawTrainInfo(ctx, departure, pids);
        handleScrollState(ctx, departure, pids);
    }

    drawFrame(ctx, pids, 10);
}

function drawBackground(ctx, pids) {
    Texture.create("Background")
        .texture("jsblock:images/pids/sncf_bg_platform_test.png")
        .size(pids.width, pids.height)
        .draw(ctx);

    Texture.create("Sncf Logo")
        .texture("jsblock:images/pids/icons/sncf.png")
        .size(7, 4)
        .pos(1.5, 1.5)
        .draw(ctx);

    Texture.create("Departure image")
        .texture("jsblock:images/pids/departs_blue_90.png")
        .size(15, 47.5)
        .pos(31.5, 18.5)
        .draw(ctx);
}

function drawClock(ctx, pids, timestamp) {
    Text.create("Clock")
        .text(formatTime(timestamp))
        .color(0xFFFFFF)
        .pos(pids.width - 11.25, pids.height - 4.5)
        .scale(0.4)
        .rightAlign()
        .draw(ctx);

    Text.create("Clock Fixed Seconds")
        .text(getSeconds(timestamp))
        .color(0xFF9F17)
        .pos(pids.width - 6.5, pids.height - 3.75)
        .scale(0.3)
        .rightAlign()
        .draw(ctx);
}

function drawDepartureInfo(ctx, departure, pids) {
    Text.create("Departure Time")
        .text(formatTime(departure.departureTime(), "h"))
        .color(0x00418D)
        .bold()
        .scale(0.6)
        .pos(1.5, 8.5)
        .draw(ctx);

    const onTimeMessages = ["À l'heure", "On time", "In orario"];
    Text.create("On Time")
        .text(onTimeMessages[Math.floor(Date.now() / 3000) % onTimeMessages.length].toLowerCase())
        .color(0x00409D)
        .centerAlign()
        .scale(0.28)
        .pos(33, 10.6)
        .draw(ctx);

    const destination = departure.destination().slice(0);
    Text.create("Destination Name")
        .text(destination)
        .color(0x00418D)
        .scale(0.525)
        .bold()
        .size(70, 10)
        .wrapText()
        .pos(1.5, 17)
        .draw(ctx);
}

function drawTrainInfo(ctx, departure, pids) {
    const routeNumber = departure.routeNumber().slice(0).toLowerCase().trim().split("|");
    const trainType = routeNumber[0];
    const trainNumber = routeNumber[1];

    let trainName = TRAIN_TYPES.findNameFromAlias(trainType) || "SNCF";
    if (trainType === "bus") trainName = "BUS SNCF";
    if (trainType === "car") trainName = "CAR SNCF";

    if (trainType === "bus") {
        Texture.create("Bus Icon")
            .texture("jsblock:images/pids/icons/bus.png")
            .size(10, 10)
            .pos(1.5, pids.height - 21.5)
            .draw(ctx);
    }

    Text.create("Train Type")
        .text(trainName)
        .color(0x00409D)
        .scale(0.3)
        .pos(1.5, 23)
        .draw(ctx);

    const posX = 1.25 + 1.25 * (1.8 * trainName.length);
    Text.create("Train Number")
        .text(trainNumber)
        .color(0x7C86B5)
        .scale(0.3)
        .bold()
        .pos(posX, 23.3)
        .draw(ctx);
}

function handleScrollState(ctx, departure, pids) {
    const now = Date.now();
    const timeSinceLastStateChange = now - lastStateChangeTime;

    let stationList = [];
    let platforms = departure.route().platforms;

    for(let i = 0; i < platforms.length; i++) { stationList.push(
        {
            name: platforms[i].stationName,
            id: platforms[i].platformId
        });
    }

    let currentStation = departure.platformId();
    let currentIndex = stationList.findIndex(station => station.id === currentStation);

    if (currentIndex !== -1) {
        stationList = stationList.slice(currentIndex + 1);
    }

    switch (currentScrollState) {
        case ScrollState.BEGIN:
            scrollOffset = 0;
            if (timeSinceLastStateChange >= timeBetweenStates * 1000) {
                currentScrollState = ScrollState.SCROLLING;
                lastStateChangeTime = now;
            }
            break;

        case ScrollState.SCROLLING:
            if (scrollInterval === null) {
                scrollInterval = FakeTimers.setInterval(() => {
                    scrollOffset += 0.075;

                    if (CURRENT_STOP >= stationList.length - MAX_VISIBLE_STOPS && scrollOffset >= (STOP_HEIGHT + 0.5)) {
                        currentScrollState = ScrollState.END;
                        lastStateChangeTime = now;
                        FakeTimers.clearInterval(scrollInterval);
                        scrollInterval = null;
                    }

                    if (scrollOffset >= (STOP_HEIGHT + 0.5) && currentScrollState === ScrollState.SCROLLING) {
                        CURRENT_STOP++;
                        scrollOffset = 0;

                        if (CURRENT_STOP > stationList.length - MAX_VISIBLE_STOPS) {
                            CURRENT_STOP = stationList.length - MAX_VISIBLE_STOPS;
                        }
                    }
                }, 50);
            }
            break;

        case ScrollState.END:
            if (timeSinceLastStateChange >= timeBetweenStates * 1000 && timeSinceLastStateChange < (timeBetweenStates + 5) * 1000) {
                currentScrollState = ScrollState.BEGIN;
                lastStateChangeTime = now;
                CURRENT_STOP = 0;
            }
            break;
    }

    drawStops(ctx, pids, stationList);
}

function drawStops(ctx, pids, stationList) {

    if(stationList.length == 0 || stationList[0].name == undefined) stationList = [ { name: "!#ERR" } ];

    const lastStationWidth = stationList[stationList.length - 1].name.slice(0).length * 2.25;

    if(stationList.length < MAX_VISIBLE_STOPS) {
        Texture.create("Aqua Line")
        .texture("jsblock:images/pids/aqua_square.png")
        .size(1.75, stationList.length * (STOP_HEIGHT + 0.5))
        .pos(48.75, 0)
        .draw(ctx);

        for (let i = 0; i < stationList.length; i++) {
            let stationName = stationList[i + CURRENT_STOP].name.slice(0);
            let multiplier = calculateMultiplier(stationName.length);

            if (i + CURRENT_STOP === stationList.length - 1) {
                Texture.create("Aqua Square")
                    .texture("jsblock:images/pids/aqua_square.png")
                    .size(lastStationWidth + 3.75 + (stationName.length * multiplier), STOP_HEIGHT + 0.75)
                    .pos(48.75, 0.5 + (i * (STOP_HEIGHT + 0.5)))
                    .draw(ctx);
            }

            Text.create("Stops")
                .text(stationName)
                .color(0xFFFFFF)
                .leftAlign()
                .scale(0.45)
                .size(75, STOP_HEIGHT)
                .pos(52.5, 1.5 + (i * (STOP_HEIGHT + 0.5)))
                .draw(ctx);

            Texture.create("Stop dot")
                .texture("jsblock:images/pids/stop_dot.png")
                .size(1.75, 1.75)
                .pos(48.75, 2.25 + (i * (STOP_HEIGHT + 0.5)))
                .draw(ctx);
        }
    } else {
        Texture.create("Aqua Line")
        .texture("jsblock:images/pids/aqua_square.png")
        .size(1.75, MAX_VISIBLE_STOPS * (STOP_HEIGHT + 0.5))
        .pos(48.75, 0 - scrollOffset)
        .draw(ctx);

        for (let i = 0; i < MAX_VISIBLE_STOPS; i++) {
            let stationName = stationList[i + CURRENT_STOP].name.slice(0);
            let multiplier = calculateMultiplier(stationName.length);

            if (i + CURRENT_STOP === stationList.length - 1) {
                Texture.create("Aqua Square")
                    .texture("jsblock:images/pids/aqua_square.png")
                    .size(lastStationWidth + 3.75 + (stationName.length * multiplier), STOP_HEIGHT + 0.75)
                    .pos(48.75, 0.5 + (i * (STOP_HEIGHT + 0.5)) - scrollOffset)
                    .draw(ctx);
            }

            Text.create("Stops")
                .text(stationName)
                .color(0xFFFFFF)
                .leftAlign()
                .scale(0.45)
                .size(75, STOP_HEIGHT)
                .pos(52.5, 1.5 + (i * (STOP_HEIGHT + 0.5)) - scrollOffset)
                .draw(ctx);

            Texture.create("Stop dot")
                .texture("jsblock:images/pids/stop_dot.png")
                .size(1.75, 1.75)
                .pos(48.75, 2.25 + (i * (STOP_HEIGHT + 0.5)) - scrollOffset)
                .draw(ctx);
        }
    }
}

function drawFrame(ctx, pids, size) {
    Texture.create("Frame-Top")
        .texture("jsblock:images/pids/gray.png")
        .size(pids.width + (size * 2), size)
        .pos(-size, -size)
        .draw(ctx);

    Texture.create("Frame-Bottom")
        .texture("jsblock:images/pids/gray.png")
        .size(pids.width + (size * 2), size)
        .pos(-size, pids.height)
        .draw(ctx);

    Texture.create("Frame-Left")
        .texture("jsblock:images/pids/gray.png")
        .size(size, pids.height + (size * 2))
        .pos(-size, -size)
        .draw(ctx);

    Texture.create("Frame-Right")
        .texture("jsblock:images/pids/gray.png")
        .size(size, pids.height + (size * 2))
        .pos(pids.width, -size)
        .draw(ctx);

    Texture.create("Sncf Logo")
        .texture("jsblock:images/pids/icons/sncf.png")
        .size(6.5, 4)
        .pos(pids.width + (size * 0.2), pids.height + (size * 0.4))
        .draw(ctx);
}

function dispose(ctx, state, pids) {}

function formatTime(timestamp, separator) {
    separator = separator || ":";

    const date = new Date(timestamp);
    const hours = date.getHours().toString().padStart(2, "0");
    const minutes = date.getMinutes().toString().padStart(2, "0");
    return `${hours}${separator}${minutes}`;
}

function getSeconds(timestamp) {
    const date = new Date(timestamp);
    return date.getSeconds().toString().padStart(2, "0");
}

function calculateMultiplier(stationNameLength) {
    const baseMultiplier = 0.33;
    const maxLength = 14;
    const minMultiplier = 0.2;

    const multiplier = baseMultiplier + (1 - (stationNameLength / maxLength)) * 0.5;

    return Math.max(minMultiplier, Math.min(multiplier, 0.75));
}